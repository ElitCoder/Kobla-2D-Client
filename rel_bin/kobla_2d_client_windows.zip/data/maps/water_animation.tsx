<?xml version="1.0" encoding="UTF-8"?>
<tileset name="water_animation" tilewidth="32" tileheight="32" tilecount="18" columns="3">
 <image source="../Hämtningar/water.gif" width="96" height="192"/>
 <tile id="17">
  <animation>
   <frame tileid="15" duration="500"/>
   <frame tileid="16" duration="500"/>
   <frame tileid="17" duration="500"/>
  </animation>
 </tile>
</tileset>
