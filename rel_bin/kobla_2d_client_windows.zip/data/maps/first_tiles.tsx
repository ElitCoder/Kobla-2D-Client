<?xml version="1.0" encoding="UTF-8"?>
<tileset name="first_tiles" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../Hämtningar/PathAndObjects.png" width="512" height="512"/>
</tileset>
